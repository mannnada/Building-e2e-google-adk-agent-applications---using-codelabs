// src/pages/Home.jsx
import React, { useState, useEffect, useRef } from 'react';
import backgroundImage from '../images/background.jpeg';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import StoreMap from '../components/StoreMap';

const BACKEND_URL = "https://finn-agent-49240794644.us-central1.run.app";

// Fix Leaflet's default icon issue
const DefaultIcon = L.icon({
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});
L.Marker.prototype.options.icon = DefaultIcon;

function enforceProductListFormat(text) {
  if (
    text &&
    !text.startsWith("Here are some products:") &&
    (text.includes("* ") || text.includes("• Product:"))
  ) {
    let lines = text.split("\n").filter(line => line.trim());
    lines = lines.filter(line =>
      !/^we have|^here are|^the following|^which would|^do you want|^would you like/i.test(line.trim())
    );
    lines = lines.filter(line =>
      !/would you like|which would you like|let me know|do you want more details/i.test(line.trim())
    );
    lines = lines.map(line => {
      if (line.startsWith("* ")) {
        let clean = line.replace(/\*\*/g, "").replace(/\*/g, "");
        const match = clean.match(/^\s*([^.]+?)[:：.\-]+ ?(.+)$/i);
        if (match) {
          const name = match[1].trim();
          const desc = match[2].trim();
          return `• Product: ${name}\n${desc}`;
        }
        return clean.replace(/^\* /, "• Product: ");
      }
      if (line.startsWith("- ")) return line.replace(/^- /, "• Product: ");
      return line;
    });
    return "Here are some products:\n" + lines.join("\n");
  }
  return text;
}

const Home = ({ idToken, setIdToken }) => {
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [messages, setMessages] = useState([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [selectedImage, setSelectedImage] = useState(null);
  const messagesEndRef = useRef(null);

  // NEW: pull a fresh token on mount (after sign-in)
  useEffect(() => {
    const t = localStorage.getItem('id_token');
    if (t && setIdToken) setIdToken(t);
  }, [setIdToken]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };
  useEffect(() => { scrollToBottom(); }, [messages]);

  useEffect(() => {
    if (isChatOpen && messages.length === 0) {
      setMessages([
        { role: 'assistant',
          content: "Welcome to GenAI Sports! I'm Finn, your AI Sport Shopping Assistant. How can I help you today?"
        }
      ]);
    }
  }, [isChatOpen, messages.length]);

  const formatMessage = (text) => {
    if (
      /^we have|^here are|^the following/i.test(text.trim()) ||
      text.includes("• Product:") ||
      text.split("\n").some(line => /^\*\s+/.test(line.trim()))
    ) {
      text = enforceProductListFormat(text);
    }

    if (text.includes('Here are some products:')) {
      const lines = text.split('\n').filter(line => line.trim());
      return (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
          {lines.map((line, index) => {
            if (line.includes('Here are some products:')) {
              return <div key={index} style={{ fontSize: '24px', fontWeight: '600' }}>{line}</div>;
            }
            if (line.startsWith('• Product:')) {
              const productName = line.split('Product:')[1].trim();
              const nextLine = lines[index + 1];
              const imageName = nextLine?.startsWith('Image:') ? nextLine.split('Image:')[1].trim() : productName;
              const description = lines[index + 2] && !lines[index + 2].startsWith('• ') ? lines[index + 2] : '';
              const imageUrl = `${BACKEND_URL}/images/${encodeURIComponent(imageName)}.png`;
              return (
                <div key={index} style={{
                  display: 'flex', alignItems: 'flex-start', gap: '32px',
                  backgroundColor: 'white', padding: '24px', borderRadius: '8px', border: '1px solid #eee'
                }}>
                  <img
                    src={imageUrl}
                    alt={productName}
                    onClick={() => setSelectedImage(imageUrl)}
                    style={{ width: '300px', height: '300px', objectFit: 'contain', cursor: 'pointer',
                             backgroundColor: 'white', borderRadius: '4px', padding: '8px' }}
                  />
                  <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: '16px' }}>
                    <div style={{ fontSize: '28px', fontWeight: '600', color: '#111827' }}>{productName}</div>
                    {description && <div style={{ fontSize: '20px', lineHeight: '1.5', color: '#4b5563' }}>{description}</div>}
                  </div>
                </div>
              );
            }
            return null;
          }).filter(Boolean)}
        </div>
      );
    }

    if (text.includes('USER|')) {
      const lines = text.trim().split('\n');
      const stores = [];
      let userLocation;
      lines.forEach(line => {
        try {
          const [name, coordinates] = line.split('|');
          if (!coordinates) return;
          const [distance, longitude, latitude] = coordinates.split(',').map(Number);
          if (isNaN(latitude) || isNaN(longitude)) return;
          if (name.trim() === 'USER') {
            userLocation = { lat: latitude, lng: longitude };
          } else {
            stores.push({ name: name.trim(), distance, latitude, longitude });
          }
        } catch {}
      });
      return (
        <div className="map-container" style={{ height: '400px', width: '100%', margin: '10px 0' }}>
          <StoreMap stores={stores} userLocation={userLocation} />
        </div>
      );
    }

    return <span style={{ whiteSpace: 'pre-line' }}>{text}</span>;
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim() || isLoading) return;

    if (!idToken) {
      alert("Please sign in with Google first!");
      return;
    }

    const userMessage = { role: 'user', content: inputMessage.trim() };
    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsLoading(true);

    try {
      const response = await fetch(`${BACKEND_URL}/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${idToken}` },
        body: JSON.stringify({ message: userMessage.content, history: messages })
      });
      if (!response.ok) throw new Error('Network response was not ok');

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let assistantMessage = { role: 'assistant', content: '' };
      setMessages(prev => [...prev, assistantMessage]);

      // Stream append
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        assistantMessage.content += decoder.decode(value, { stream: true });
        setMessages(prev => {
          const newMessages = [...prev];
          newMessages[newMessages.length - 1] = { ...assistantMessage };
          return newMessages;
        });
      }
    } catch (error) {
      console.error('Error:', error);
      setMessages(prev => [...prev, { role: 'assistant', content: "I'm sorry, I encountered an error. Please try again." }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const ImageModal = ({ imageUrl, onClose }) => (
    <div
      style={{
        position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
        backgroundColor: 'rgba(0, 0, 0, 0.8)', display: 'flex',
        justifyContent: 'center', alignItems: 'center', zIndex: 2000, cursor: 'pointer'
      }}
      onClick={onClose}
    >
      <div style={{ position: 'relative', maxWidth: '90%', maxHeight: '90%' }}>
        <img
          src={imageUrl}
          alt="Large product view"
          style={{ maxWidth: '100%', maxHeight: '90vh', objectFit: 'contain', borderRadius: '8px', backgroundColor: 'white', padding: '10px' }}
        />
        <button
          onClick={onClose}
          style={{ position: 'absolute', top: '-40px', right: '-40px', background: 'none', border: 'none', color: 'white', fontSize: '30px', cursor: 'pointer' }}
        >
          ×
        </button>
      </div>
    </div>
  );

  return (
    <div style={{ backgroundColor: 'white', display: 'flex', justifyContent: 'center', height: 'calc(100vh - 80px)' }}>
      {/* Debug chip so you can confirm token presence */}
      <div style={{position:'fixed', top:84, right:16, zIndex:1100, background:'#111827', color:'#fff',
                   padding:'6px 10px', borderRadius:8, fontSize:12}}>
        {idToken ? 'ID token ✓' : 'No ID token'}
      </div>

      <div style={{ position: 'relative', width: '100%', height: '100%' }}>
        <img src={backgroundImage} alt="Hiking adventure"
             style={{ width: '100%', height: '100%', objectFit: 'cover', position: 'relative' }} />

        <div style={{
          position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)',
          textAlign: 'center', width: '100%', maxWidth: '800px', padding: '0 2rem', zIndex: 2
        }}>
          <h1 style={{ fontSize: '4rem', fontWeight: 'bold', color: 'white', marginBottom: '1.5rem' }}>
            Run with purpose. Run with power.
          </h1>
          <p style={{ fontSize: '1.5rem', color: 'white', marginBottom: '2rem' }}>
            Spring Running Collection — Elevate your performance with our newest running essentials.
            Experience the thrill of every challenge.
          </p>
          <button onClick={() => setIsChatOpen(true)}
                  style={{ backgroundColor: 'white', color: 'black', padding: '1rem 2rem', borderRadius: '0.25rem',
                           border: 'none', cursor: 'pointer', fontSize: '1.25rem', fontWeight: '500' }}>
            Shop Now
          </button>
        </div>

        <div style={{
          position: 'absolute', bottom: '20px', right: '20px', color: 'white', fontSize: '0.9rem',
          backgroundColor: 'rgba(0, 0, 0, 0.5)', padding: '8px 12px', borderRadius: '4px', zIndex: 2
        }}>
          Built on <span style={{ textDecoration: 'underline', fontWeight: 'bold' }}>AlloyDB</span> using a Synthetic Dataset
        </div>

        {isChatOpen && (
          <div style={{
            position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0, 0, 0, 0.5)',
            display: 'flex', justifyContent: 'center', alignItems: 'center', zIndex: 1000
          }}>
            <div style={{ width: '1536px', height: '80vh', backgroundColor: 'white', borderRadius: '12px',
                          display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
              <div style={{ padding: '20px', borderBottom: '1px solid #eee', display: 'flex',
                            justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#f8f9fa' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                  <span className="material-icons" style={{ color: '#2563eb', fontSize: '28px' }}>directions_run</span>
                  <h3 style={{ margin: 0, fontWeight: '700', fontSize: '1.5rem', color: '#1f2937' }}>
                    Finn - Your Sports Shopping Assistant
                  </h3>
                </div>
                <button onClick={() => setIsChatOpen(false)}
                        style={{ border: 'none', background: 'none', cursor: 'pointer', fontSize: '1.8rem', color: '#6b7280' }}>
                  ×
                </button>
              </div>

              <div style={{ flex: 1, padding: '16px', overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '12px' }}>
                {messages.map((message, index) => (
                  <div key={index} style={{
                    alignSelf: message.role === 'user' ? 'flex-end' : 'flex-start',
                    maxWidth: '70%', padding: '16px 20px', borderRadius: '12px',
                    backgroundColor: message.role === 'user' ? '#2563eb' : '#f3f4f6',
                    color: message.role === 'user' ? 'white' : 'black', fontSize: '24px'
                  }}>
                    {message.role === 'user' ? message.content : <div>{formatMessage(message.content)}</div>}
                  </div>
                ))}
                <div ref={messagesEndRef} />
                {isLoading && (
                  <div style={{ alignSelf: 'flex-start', padding: '12px 16px', borderRadius: '12px',
                                backgroundColor: '#f3f4f6', color: 'black', fontSize: '24px' }}>
                    Typing...
                  </div>
                )}
              </div>

              <div style={{ padding: '16px', borderTop: '1px solid #eee', backgroundColor: 'white' }}>
                <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
                  <input
                    type="text"
                    value={inputMessage}
                    onChange={(e) => setInputMessage(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder="Type your message..."
                    style={{ flex: 1, padding: '12px 16px', borderRadius: '24px', border: '1px solid #ddd',
                             fontSize: '24px', outline: 'none', backgroundColor: 'white' }}
                  />
                  <button
                    onClick={handleSendMessage}
                    disabled={isLoading || !inputMessage.trim()}
                    style={{
                      backgroundColor: isLoading || !inputMessage.trim() ? '#93c5fd' : '#2563eb',
                      color: 'white', border: 'none', borderRadius: '50%', width: '40px', height: '40px',
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      cursor: isLoading || !inputMessage.trim() ? 'not-allowed' : 'pointer'
                    }}
                  >
                    <span className="material-icons" style={{ fontSize: '20px' }}>send</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {selectedImage && (
          <div
            style={{ position: 'fixed', top: 0, left: 0, width: '100%', height: '100%',
                     backgroundColor: 'rgba(0, 0, 0, 0.8)', display: 'flex',
                     justifyContent: 'center', alignItems: 'center', zIndex: 9999 }}
            onClick={() => setSelectedImage(null)}
          >
            <div style={{ position: 'relative' }}>
              <button onClick={() => setSelectedImage(null)}
                      style={{ position: 'absolute', top: '-40px', right: '-40px', background: 'none',
                               border: 'none', color: 'white', fontSize: '30px', cursor: 'pointer',
                               padding: '10px', zIndex: 10000 }}>
                ×
              </button>
              <img src={selectedImage} alt="Enlarged view"
                   style={{ maxWidth: '90%', maxHeight: '90%', objectFit: 'contain',
                            backgroundColor: 'white', padding: '20px', borderRadius: '8px' }}
                   onClick={e => e.stopPropagation()} />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Home;
