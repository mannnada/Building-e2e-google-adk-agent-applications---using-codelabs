// src/components/GoogleSignInButton.jsx
import React, { useEffect, useRef } from "react";

const CLIENT_ID = "49240794644-4dpl93q5vrljg8rthsda4s5kdfrdrav9.apps.googleusercontent.com";

export default function GoogleSignInButton({ onSignIn }) {
  const scriptLoadedRef = useRef(false);

  useEffect(() => {
    // Already loaded?
    if (scriptLoadedRef.current) return;

    const script = document.createElement("script");
    script.src = "https://accounts.google.com/gsi/client";
    script.async = true;
    script.defer = true;

    script.onload = () => {
      scriptLoadedRef.current = true;
      if (!window.google?.accounts?.id) {
        console.error("[GIS] google.accounts.id not available");
        return;
      }

      // Initialize GIS
      window.google.accounts.id.initialize({
        client_id: CLIENT_ID,
        callback: (response) => {
          const token = response?.credential;
          console.log("[GIS] credential callback fired. Token present:", !!token);
          if (!token) {
            console.error("[GIS] No ID token in response. Check OAuth origins.");
            return;
          }
          try {
            localStorage.setItem("id_token", token);
          } catch (e) {
            console.error("[GIS] Failed to write token to localStorage", e);
          }
          onSignIn?.(token);
        },
        ux_mode: "popup",                // force popup (more reliable in Cloud Run)
        context: "signin",
        auto_select: false,
        cancel_on_tap_outside: false,
      });

      // Render the Google button into our placeholder
      window.google.accounts.id.renderButton(
        document.getElementById("google-signin-btn"),
        { theme: "outline", size: "large", type: "standard", shape: "rectangular" }
      );

      // Prompt opens an account chooser if user already authorized
      try {
        window.google.accounts.id.prompt((notification) => {
          console.log("[GIS] prompt:", notification);
        });
      } catch (e) {
        console.warn("[GIS] prompt failed", e);
      }
    };

    script.onerror = (e) => {
      console.error("[GIS] Failed to load Google script", e);
    };

    document.body.appendChild(script);
    return () => {
      try { document.body.removeChild(script); } catch {}
    };
  }, [onSignIn]);

  return (
    <div
      id="google-signin-btn"
      aria-label="Sign in with Google"
      style={{ display: "inline-block" }}
    />
  );
}
