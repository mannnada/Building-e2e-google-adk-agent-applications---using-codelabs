import React, { useEffect } from "react";
import GoogleSignInButton from "../components/GoogleSignInButton";


export default function Header({ idToken, setIdToken }) {
  useEffect(() => {
    // restore token on refresh
    const saved = localStorage.getItem("id_token");
    if (saved) setIdToken(saved);
  }, [setIdToken]);

  const handleSignIn = (token) => {
    setIdToken(token);
  };

  const handleSignOut = () => {
    try { localStorage.removeItem("id_token"); } catch {}
    try { window.google?.accounts?.id?.disableAutoSelect?.(); } catch {}
    setIdToken?.(null);
  };


  return (
    <header className="flex items-center justify-between px-6 py-4">
      <div className="text-xl font-semibold">GenAISports</div>

      <div>
        {idToken ? (
          <button
            onClick={handleSignOut}
            className="px-4 py-2 rounded bg-black text-white"
          >
            Sign Out
          </button>
        ) : (
          <GoogleSignInButton onSignIn={handleSignIn} />
        )}
      </div>
    </header>
  );
}
