# src/backend/app.py
import os
import uuid
import logging
import traceback
from fastapi import FastAPI, Request, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse, RedirectResponse

from finn_agent import process_message as finn_chat, run_once as finn_run_once

logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

BUCKET_NAME = os.getenv("GCS_BUCKET_NAME", "sport-store-agent-ai-bck01")

app = FastAPI()

# CORS (relaxed for demo)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/test")
async def test():
    return {"status": "ok", "message": "Backend is running"}

@app.post("/chat")
async def chat(request: Request):
    """
    Streaming endpoint. IMPORTANT: Use curl with -i -N to see streamed output.
    """
    try:
        data = await request.json()
        message = data.get("message")
        if not message:
            raise HTTPException(status_code=400, detail="No 'message' field in request")

        history = data.get("history", [])
        session_id = data.get("session_id") or str(uuid.uuid4())
        user_id = data.get("user_id") or "default-user"

        # Forward raw Authorization header; finn_agent handles "Bearer " prefix
        id_token = request.headers.get("Authorization")

        event_stream_func = await finn_chat(
            message, history, session_id, user_id, id_token=id_token
        )
        return StreamingResponse(event_stream_func(), media_type="text/plain")

    except HTTPException:
        raise
    except Exception as e:
        logger.error("Error in /chat: %s\n%s", str(e), traceback.format_exc())
        # Return JSON error (non-stream) so clients don't hang
        raise HTTPException(status_code=500, detail="Internal error in /chat")

@app.post("/chat_nostream")
async def chat_nostream(request: Request):
    try:
        data = await request.json()
        message = data.get("message")
        if not message:
            raise HTTPException(status_code=400, detail="No message field in request")

        history = data.get("history", [])
        session_id = data.get("session_id") or str(uuid.uuid4())
        user_id = data.get("user_id") or "default-user"

        id_token = request.headers.get("Authorization")

        # IMPORTANT: call the non-stream helper from finn_agent
        from finn_agent import run_once
        full_text = await run_once(message, history, session_id, user_id, id_token=id_token)

        return JSONResponse({"response": full_text})
    except Exception as e:
        logger.error(f"Error in chat_nostream endpoint: {str(e)}\n{traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/images/{filename}")
async def serve_image(filename: str):
    public_url = f"https://storage.googleapis.com/{BUCKET_NAME}/images/{filename}"
    return RedirectResponse(url=public_url)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)
