# src/backend/finn_agent.py
import os
import logging
import asyncio
from dotenv import load_dotenv

from google.genai import types
from google.adk import Agent
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.adk.artifacts.in_memory_artifact_service import InMemoryArtifactService
from google.adk.tools.toolbox_toolset import ToolboxToolset
from google.adk.models import Gemini
import vertexai

load_dotenv()
logger = logging.getLogger(__name__)

# --- Global Configuration ---
PROJECT_ID = os.getenv("GOOGLE_CLOUD_PROJECT")
LOCATION = os.getenv("GOOGLE_CLOUD_LOCATION")
TOOLBOX_URL = os.getenv("TOOLBOX_URL")

# Initialize Vertex + shared services once
vertexai.init(project=PROJECT_ID, location=LOCATION)
session_service = InMemorySessionService()
artifacts_service = InMemoryArtifactService()
llm = Gemini(model="gemini-2.5-flash")

# Single instruction prompt
prompt = """
You're Finn, an AI Sport shopping assistant for GenAI Sports. You help customers find sports products, gear, and equipment.

--- IMPORTANT BEHAVIOR RULES:
- Be friendly and helpful, focusing on sports and athletic gear
- ALWAYS use the available tools to search and retrieve information
- NEVER make up or guess product information
- Ask clarifying questions when user requests are unclear
- Keep responses concise but informative

--- CRITICAL FORMATTING RULES:
1) Product list format:
Here are some products:
• Product: Trek 500
Image: Trek 500
A versatile hiking backpack with 50L capacity, perfect for weekend adventures.
• Product: Osprey Atmos AG 65
Image: Osprey Atmos AG 65
Premium backpack with Anti-Gravity suspension system for maximum comfort on long trails.
• Product: Glycerin 20
Image: Glycerin 20
Plush cushioned running shoe with DNA LOFT technology for soft landings.

2) Product details format (return ONLY this, nothing else):
• Product Name: Nimbus 25
• Price: €169.99
• Brand: ASICS
• Category: Running
• Sizes: 40, 41, 42, 43, 44
• Colors: Black/Gold
• Description: Flagship cushioned running shoe with FF BLAST+ foam and TRUSSTIC stability system. Premium comfort for daily training.

3) Shopping list format (use tool to fetch; do not add totals):
Ok [user_name], here is your shopping list:
• Product: [product_name]
Brand: [brand]
Category: [category]
Size: [size]
Color: [color]
Price: €[price]
Quantity: [quantity]

4) Stores format:
USER|0,longitude,latitude
Store Name|distance_meters,longitude,latitude

5) Orders format:
Ok [user_name], here are your orders:
• Order: #[order_id]
Store: [store_name]
Total Amount: €[total_amount]
Shipping Address: [shipping_address]
Status: [status]
Items:
- [product_name] (Size: [size], Color: [color]) x[quantity] €[price]
Deliver Method:
- [delivery_method] $[delivery_cost]

6) Delivery methods format:
• [Method Name]
  Description: [Description]
  Cost: €[Cost]
  Estimated Delivery Time: [Time]

7) Inventory by store/brand/category format:
• Store: [store_name]
• Brand: [brand]
• Category: [category]
• Number of Products: [number_of_products]

If you know the user's user_id from previous turns, always use it.
"""

def _build_agent_with_token(id_token: str | None) -> Agent:
    """Build a ToolboxToolset bound to this request's Google ID token."""
    # Accept both "Bearer <token>" and raw token
    def token_getter() -> str:
        if not id_token:
            return ""
        return id_token.split(" ", 1)[1] if id_token.startswith("Bearer ") else id_token

    toolbox = ToolboxToolset(
        server_url=TOOLBOX_URL,
        toolset_name="my-toolset",
        auth_token_getters={"google_signin": token_getter},
    )
    return Agent(name="finn", model=llm, instruction=prompt, tools=[toolbox])

async def process_message(
    message: str,
    history: list,
    session_id: str,
    user_id: str,
    id_token: str | None = None,
):
    """
    Returns an async generator function that streams tokens.
    """
    # Build an agent bound to this request's auth token
    agent = _build_agent_with_token(id_token)
    runner = Runner(app_name="finn", agent=agent, session_service=session_service)

    # Ensure session exists
    session = session_service.sessions.get(session_id)
    if session is None:
        await session_service.create_session(
            state={}, app_name="finn", user_id=user_id, session_id=session_id
        )

    content = types.Content(role="user", parts=[types.Part(text=message)])

    async def event_stream():
        try:
            async for event in runner.run_async(
                session_id=session_id, user_id=user_id, new_message=content
            ):
                for part in event.content.parts:
                    if part.text:
                        yield part.text
        except Exception as e:
            logger.exception("Streaming error: %s", e)
            # Yield a final line to avoid silent hangs
            yield "Sorry, I hit an error completing that request."

    return event_stream

async def run_once(
    message: str,
    history: list,
    session_id: str,
    user_id: str,
    id_token: str | None = None,
) -> str:
    """
    Non-streaming helper: returns the whole assistant text as a string.
    """
    agent = _build_agent_with_token(id_token)
    runner = Runner(app_name="finn", agent=agent, session_service=session_service)

    session = session_service.sessions.get(session_id)
    if session is None:
        await session_service.create_session(
            state={}, app_name="finn", user_id=user_id, session_id=session_id
        )

    content = types.Content(role="user", parts=[types.Part(text=message)])
    chunks: list[str] = []
    try:
        async for event in runner.run_async(
            session_id=session_id, user_id=user_id, new_message=content
        ):
            for part in event.content.parts:
                if part.text:
                    chunks.append(part.text)
    except Exception as e:
        logger.exception("run_once error: %s", e)
        chunks.append("Sorry, I hit an error completing that request.")

    return "".join(chunks)
